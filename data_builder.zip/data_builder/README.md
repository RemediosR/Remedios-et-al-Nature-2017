# data_builder
A graphical interface for tying together experimental data and metadata, and loading it into Matlab.

This is a pared-down version of the data_builder that comes packaged with [Bento](https://github.com/annkennedy/bento), designed to work specifically with calcium imaging, behavior annotation, and tracking data. 

## Contents
Data collection & preprocessing: Ryan Remedios
Bento GUI: Ann Kennedy
